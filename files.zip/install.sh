#!/bin/bash
# Install the autoresearch skill to ~/.claude/skills/
# Usage: bash install.sh

set -e

SKILL_DIR="$HOME/.claude/skills/autoresearch"

if [ -d "$SKILL_DIR" ]; then
    echo "⚠  Skill directory already exists: $SKILL_DIR"
    read -p "   Overwrite? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Aborted."
        exit 0
    fi
    rm -rf "$SKILL_DIR"
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

mkdir -p "$SKILL_DIR"
cp -r "$SCRIPT_DIR/autoresearch-skill/"* "$SKILL_DIR/"

echo "✓ Installed autoresearch skill to $SKILL_DIR"
echo ""
echo "Directory structure:"
find "$SKILL_DIR" -type f | sed "s|$HOME|~|" | sort
echo ""
echo "Usage in Claude Code:"
echo "  /autoresearch              — start guided setup"
echo "  /autoresearch my algorithm — start with a target in mind"
